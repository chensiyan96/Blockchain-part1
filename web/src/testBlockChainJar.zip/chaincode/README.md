1. return value will be compose in class `github.com/hyperledger/fabric/protos/peer`
2. query functions return json object in `[]byte`