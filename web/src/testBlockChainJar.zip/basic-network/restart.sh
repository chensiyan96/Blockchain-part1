#  When stop network, run this script to restart network.
docker start cli peer0.org1.example.com peer1.org1.example.com couchdb orderer.example.com ca.example.com